<?php

      require_once 'functions.php';
    
    //if(isset($_POST['id']) && isset($_POST['plot'])){
        
        $id = "1";//$_POST['id'];
        $plot = "14";//$_POST['plot'];
   // }

    $userObject = new Functions();

    
    if(!empty($id) && !empty($plot)){

    	$userObject = new Functions();
 
        $userObject->messages($id,$plot);
        
        echo $userObject->messages($id,$plot);
 	}

?>