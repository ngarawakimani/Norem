<?php

    require_once 'functions.php';
    
    //if(isset($_POST['id'])){
        
        $id = "1";//$_POST['id'];
   // }

    $userObject = new Functions();

    
    if(!empty($id)){
        
        
        //$userObject->room($national_id);
        
        echo $userObject->room($id);
        
    }

?>