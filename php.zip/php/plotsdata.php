<?php
	require_once 'functions.php';

	$object = new Functions();

	$object->plots();
?>