<?php

    require_once 'functions.php';
    
    //if(isset($_POST['id']) && isset($_POST['plot']) && isset($_POST['room']) && isset($_POST['duration'])){
        
        $national_id = "28643898";//$_POST['id'];
        $plot = $_POST['plot'];
        $room = $_POST['room'];
        $duration = $_POST['duration'];
   // }

         $date = date("m/d/y");

         echo $date;

    $userObject = new Functions();

    
    if(!empty($national_id)){
        
        
        //$userObject->createRequest($national_id, $password);
        
        echo $userObject->createRequest($national_id,$plot,$room,$date,$duration);
    }

?>