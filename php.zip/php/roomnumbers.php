<?php

    require_once 'functions.php';
    
    if(isset($_POST['plot'])){
        
        $plot = $_POST['plot'];
   }

    $userObject = new Functions();

   
    
    if(!empty($plot)){
        
        echo $userObject->roomNumbers($plot);
    }

?>