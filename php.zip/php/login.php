<?php
    
    require_once 'functions.php';
    
    if(isset($_POST['id']) && isset($_POST['password'])){
        
        $national_id = $_POST['id'];
        $password = $_POST['password'];
    }else{
        echo "id and password empty";
    }

    $userObject = new Functions();

    // Login
    
    if(!empty($national_id) && !empty($password)){
        
        $status = $userObject->loginUsers($national_id, $password);
        
        echo $status;
    }

?>    