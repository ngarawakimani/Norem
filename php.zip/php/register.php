<?php
    
    require_once 'functions.php';
    

    
    if(isset($_POST['firstname']) && isset($_POST['secondname']) && isset($_POST['id']) && isset($_POST['phone']) && isset($_POST['gender']) && isset($_POST['password']) && isset($_POST['photo']) && isset($_POST['email'])){
        
        $firstname = $_POST['firstname'];
        $secondname = $_POST['secondname'];
        $national_id = $_POST['id'];
        $phone = $_POST['phone'];
        $gender = $_POST['gender'];
        $password = $_POST['password'];
        $photo = $_FILES['file']['name'];
        $email = $_POST['email'];
    }

    $file_path = "photos/";
     
    $file_path = $file_path . basename($photo);
    if(move_uploaded_file($_FILES['file']['tmp_name'], $file_path)) {
        $result = "success";
    } else{
        $result = "error";
    } 
    
    $userObject = new Functions();
    
    // Registration
    
    if(!empty($firstname) && !empty($secondname) && !empty($national_id) && !empty($phone) && !empty($gender) && !empty($password) && !empty($photo) && !empty($email) && !empty($scanned_id)){
        
        //$hashed_password = md5($password);
        
        $json_registration = $userObject->newUser($firstname, $secondname, $national_id, $phone, $gender, $password, $photo, $email, $scanned_id);
        
        echo $json_registration;
        
    }

?>    