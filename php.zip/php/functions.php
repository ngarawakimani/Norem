<?php
    
    include_once 'DbConnect.php';
    
    class Functions{
        
        private $db;
        
        public function __construct(){
            $this->db = new DbConnect();
        }

        public function plots(){
            
            $query = "select plots.name,plots.image,room.details,room.rent,room.capacity from plots,room where room.status=0";
            
            $result = mysqli_query($this->db->getDb(), $query);
            
            if ($result->num_rows >0) {
                // output data of each row
                while($row[] = $result->fetch_assoc()) {
                     
                    $tem = $row;
                         
                    $json = json_encode($tem);
                     
                     
                }
                     
            } else {
                echo "0 results";
            }

            echo $json;

            
            mysqli_close($this->db->getDb());
            
        }

        public function room($national_id){
            
            $query = "select tenants.roomName,tenants.rent,room.details,tenants.conditin,tenants.capacity from tenants,room where tenants.nationalId=".$national_id."";
            
            $result = mysqli_query($this->db->getDb(), $query);
            
            if ($result->num_rows >0) {
                // output data of each row
                while($row[] = $result->fetch_assoc()) {
                     
                    $tem = $row;
                         
                    $json = json_encode($tem);
                     
                     
                }
                     
            } else {
                echo "0 results";
            }

            echo $json;

            
            mysqli_close($this->db->getDb());
            
        }

        public function roomNumbers($plot){

            /*$query1 = "select plotId from plots where name=".$plot."";

            $result1 = mysqli_query($this->db->getDb(), $query1);

            $row = $result1->fetch_assoc();
                     
                    $id = $row['plotId'];*/
                         
             
            
            $query = "select name from room where plotId=7";
            
            $result = mysqli_query($this->db->getDb(), $query);
            
            if ($result->num_rows >0) {
                // output data of each row
                while($row[] = $result->fetch_assoc()) {
                     
                    $tem = $row;
                         
                    @$json = json_encode($tem);
                     
                     
                }
                     
            } else {
                echo "0 results";
            }

            echo $json;

            
            mysqli_close($this->db->getDb());
            
        }
        
        public function messages($user_id,$plot){

            $query = "SELECT `headline`,`topic`,`date` FROM `messages` WHERE user_id=".$user_id." OR groupId=0 or groupId=".$plot." ORDER BY id DESC limit 5" ;
            
            $result = mysqli_query($this->db->getDb(), $query);
            
            if ($result->num_rows >0) {
                // output data of each row
                while($row[] = $result->fetch_assoc()) {
                     
                    $tem = $row;
                         
                    $json = json_encode($tem);
                     
                     
                }
                     
            } else {
                echo "0 results";
            }

            echo $json;

            
            mysqli_close($this->db->getDb());
            
        }
        
        public function userLogin($national_id, $password){
            
            $query = "select * from users where nationalid ='$national_id' AND password = '$password' Limit 1";
            
            $result = mysqli_query($this->db->getDb(), $query);
            
            if(mysqli_num_rows($result) > 0){
                
                mysqli_close($this->db->getDb());
                
                
                return true;
            }else{
                
            }
            
            mysqli_close($this->db->getDb());
            
            return false;
            
        }
        
        public function checkCredentials($national_id, $phone){
            
            $query = "select * from users where nationalId = '$national_id' AND phone = '$phone'";
            
            $result = mysqli_query($this->db->getDb(), $query);
            
            if(mysqli_num_rows($result) > 0){
                
                mysqli_close($this->db->getDb());
                
                return true;
                
            }
            
            
            return false;
            
        }
        
        public function isValidEmail($email){
            return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
        }
        
        
        
        public function newUser($firstname, $secondname, $national_id, $phone, $gender, $password, $photo, $email, $scanned_id){
            
            
            $isExisting = $this->checkCredentials($national_id, $phone);
            
            
            if($isExisting){
                
                $status = "Error:national id/phone already exists";
            }
            
            else{
                
            $isValid = $this->isValidEmail($email);
                
                if($isValid)
                {
                $query = "insert into users (fname, sname, nationalId, phone, gender, password, photo, email, scannedId)
                         values ('$firstname', '$secondname', $national_id, '$phone', '$gender', '$password', '$photo', '$email','$scanned_id')";
                
                $inserted = mysqli_query($this->db->getDb(), $query);
                
                if($inserted == 1){

                    $status = "Successfully registered the user";
                    
                }else{

                    $status  = "failed to register";
                    
                }
                
                mysqli_close($this->db->getDb());
                }
                else{
                    $status = "Email Address is not valid";
                }
                
            }
            
            return $status;
            
        }
        
        public function loginUsers($national_id, $password){
            
            $json = array();
            
            $canUserLogin = $this->userLogin($national_id, $password);
            
            if($canUserLogin){
  
                $status= "Successfully logged in";
                
            }else{
                $status= "Incorrect details";
            }
            return $status;
        }

        public function createRequest($national_id,$plot,$room,$date,$duration){
            
            $query = "select users.user_id,plots.plot_id,room.name, from users,plots,room where users.nationalid = '$national_id'";
            
            $result = mysqli_query($this->db->getDb(), $query);
            
            if(mysqli_num_rows($result) > 0){

                while($row[] = $result->fetch_assoc()) {
                     
                    @$user_id = $row['id'];
                    @$plot_id = $row['plotId'];
                    @$room_id = $row['id'];
                     
                     //echo @$item;

                     //insert data to request table
                    $query1 = "INSERT INTO `request`(`user_id`, `plot_id`, `room_id`, `date`, `duration`, `status`)
                                            VALUES ('$user_id','$plot_id','$room_id','$date','$duration',null)";
            
                    $result1 = mysqli_query($this->db->getDb(), $query1);
                     
                }
                
                return true;
                
            }
            
            mysqli_close($this->db->getDb());
            return false;
            
        }

    }
    ?>