-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.6.16 - MySQL Community Server (GPL)
-- Server OS:                    Win32
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping database structure for norem
DROP DATABASE IF EXISTS `norem`;
CREATE DATABASE IF NOT EXISTS `norem` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `norem`;


-- Dumping structure for table norem.landlord
DROP TABLE IF EXISTS `landlord`;
CREATE TABLE IF NOT EXISTS `landlord` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(50) NOT NULL,
  `sname` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `nationalId` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `photo` mediumblob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;



-- Dumping structure for table norem.messages
DROP TABLE IF EXISTS `messages`;
CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `groupId` int(11) DEFAULT NULL,
  `Sender` int(11) DEFAULT NULL,
  `headline` varchar(50) DEFAULT NULL,
  `topic` varchar(150) DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL,
  `status` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;

-- Dumping data for table norem.messages: ~13 rows (approximately)
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
REPLACE INTO `messages` (`id`, `user_id`, `groupId`, `Sender`, `headline`, `topic`, `date`, `status`) VALUES
	(1, 2, NULL, 3, 'Request Accepted', 'Conguragulations! your  Request of room kiambuo on plot Koitabut Has been Accepted !', '2016-11-13 00:00:00', 0),
	(2, 1, NULL, 3, 'Request Deny', 'We are sorry to inform you that Your Request of room Migodini on plot Koitabut Has been Denied !', '2016-11-13 00:00:00', 0),
	(3, 2, NULL, 3, 'Request Accepted', 'Conguragulations! your  Request of room kiambuo on plot Koitabut Has been Accepted !', NULL, 0),
	(4, 1, NULL, 3, 'Request Deny', 'We are sorry to inform you that Your Request of room Migodini on plot Koitabut Has been Denied !', NULL, 0),
	(5, 3, NULL, 3, 'Request Accepted', 'Conguragulations! your  Request of room R0022 on plot kiambion Has been Accepted !', NULL, 0),
	(6, 4, NULL, 3, 'Request Accepted', 'Conguragulations! your  Request of room R0022 on plot kiambion Has been Accepted !', NULL, 0),
	(7, 1, NULL, 3, 'Request Accepted', 'Conguragulations! your  Request of room R001 on plot Koitabut Has been Accepted !', NULL, 0),
	(8, 2, NULL, 3, 'Request Accepted', 'Conguragulations! your  Request of room R001 on plot Koitabut Has been Accepted !', NULL, 0),
	(9, 2, NULL, 3, 'Request Accepted', 'Conguragulations! your  Request of room R001 on plot Koitabut Has been Accepted !', NULL, 0),
	(10, 2, NULL, 3, 'Request Accepted', 'Conguragulations! your  Request of room R001 on plot Koitabut Has been Accepted !', NULL, 0),
	(11, 4, NULL, 3, 'Request Accepted', 'Conguragulations! your  Request of room R002 on plot Ruai Has been Accepted !', NULL, 0),
	(12, NULL, 7, 3, '12', '1213wew', NULL, 0),
	(13, NULL, 0, 3, 'hamuami', 'manze hameni', NULL, 0),
	(14, NULL, 10, 3, 'nadai rent', 'kama hukulipa rent mjamaa utaona shida', '29/11/2016  14:30:53', 0),
	(15, NULL, 7, 3, 'dugd', 'fhrgmerdjhjsh dhf jfde', '29/11/2016  18:31:27', 0),
	(16, 4, NULL, NULL, 'Request Accepted', 'Conguragulations! your  Request of room R004t5 on plot Ruaie Has been Accepted ! Check in before ;', NULL, 0),
	(17, 4, NULL, NULL, 'Request Accepted', 'Conguragulations! your  Request of room R004t5 on plot Ruaie Has been Accepted ! Check in before ;', NULL, 0),
	(18, 4, NULL, NULL, 'Request Accepted', 'Conguragulations! your  Request of room R004t5 on plot Ruaie Has been Accepted ! Check in before ;', NULL, 0),
	(19, 4, NULL, NULL, 'Request Accepted', 'Conguragulations! your  Request of room R004t5 on plot Ruaie Has been Accepted ! Check in before ;', NULL, 0),
	(20, 4, NULL, NULL, 'Request Accepted', 'Conguragulations! your  Request of room R004t5 on plot Ruaie Has been Accepted ! Check in before ;10/12/2016', NULL, 0),
	(21, 4, NULL, NULL, 'Request Accepted', 'Conguragulations! your  Request of room R004t5 on plot Ruaie Has been Accepted ! Check in before ;10/12/2016', NULL, 0),
	(22, 6, NULL, NULL, 'You need to signed Out', 'Your days of being in the room are due you need to sign out', NULL, 0),
	(23, 2, NULL, NULL, 'You need to signed Out', 'Your days of being in the room are due you need to sign out', NULL, 0),
	(24, 2, NULL, NULL, 'You need to signed Out', 'Your days of being in the room are due you need to sign out', '30/11/2016  23:28:05', 0),
	(25, 2, NULL, NULL, 'You need to signed Out', 'Your days of being in the room are due you need to sign out', '30/11/2016  23:28:27', 0),
	(26, 2, NULL, NULL, 'You need to signed Out', 'Your days of being in the room are due you need to sign out', '30/11/2016  23:28:43', 0),
	(27, 2, NULL, NULL, 'You need to signed Out', 'Your days of being in the room are due you need to sign out', '30/11/2016  23:28:49', 0),
	(28, 2, NULL, NULL, 'You need to signed Out', 'Your days of being in the room are due you need to sign out', '30/11/2016  23:29:51', 0),
	(29, 2, NULL, NULL, 'You need to signed Out', 'Your days of being in the room are due you need to sign out', '30/11/2016  23:30:04', 0),
	(30, 2, NULL, NULL, 'You need to signed Out', 'Your days of being in the room are due you need to sign out', '30/11/2016  23:30:11', 0),
	(31, 2, NULL, NULL, 'You need to signed Out', 'Your days of being in the room are due you need to sign out', '30/11/2016  23:32:15', 0),
	(32, 2, NULL, NULL, 'You need to signed Out', 'Your days of being in the room are due you need to sign out', '30/11/2016  23:32:37', 0),
	(33, 2, NULL, NULL, 'You need to signed Out', 'Your days of being in the room are due you need to sign out', '30/11/2016  23:35:22', 0),
	(34, 2, NULL, NULL, 'You need to signed Out', 'Your days of being in the room are due you need to sign out', '30/11/2016  23:35:33', 0),
	(35, 2, NULL, NULL, 'You need to signed Out', 'Your days of being in the room are due you need to sign out', '30/11/2016  23:35:50', 0),
	(36, 2, NULL, NULL, 'You need to signed Out', 'Your days of being in the room are due you need to sign out', '30/11/2016  23:36:07', 0),
	(37, 2, NULL, NULL, 'You need to signed Out', 'Your days of being in the room are due you need to sign out', '30/11/2016  23:40:28', 0),
	(38, 2, NULL, NULL, 'You need to signed Out', 'Your days of being in the room are due you need to sign out', '30/11/2016  23:41:06', 0),
	(39, 2, NULL, NULL, 'You need to signed Out', 'Your days of being in the room are due you need to sign out', '30/11/2016  23:42:03', 0),
	(40, 2, NULL, NULL, 'You need to signed Out', 'Your days of being in the room are due you need to sign out', '30/11/2016  23:45:08', 0),
	(41, 2, NULL, NULL, 'You need to signed Out', 'Your days of being in the room are due you need to sign out', '30/11/2016  23:46:27', 0),
	(42, 2, NULL, NULL, 'You need to signed Out', 'Your days of being in the room are due you need to sign out', '30/11/2016  23:47:17', 0),
	(43, 2, NULL, NULL, 'You need to signed Out', 'Your days of being in the room are due you need to sign out', '30/11/2016  23:49:59', 0),
	(44, 2, NULL, NULL, 'You need to signed Out', 'Your days of being in the room are due you need to sign out', '30/11/2016  23:50:20', 0),
	(45, 2, NULL, NULL, 'You need to signed Out', 'Your days of being in the room are due you need to sign out', '30/11/2016  23:51:06', 0),
	(46, 2, NULL, NULL, 'You need to signed Out', 'Your days of being in the room are due you need to sign out', '30/11/2016  23:53:05', 0),
	(47, 2, NULL, NULL, 'You need to signed Out', 'Your days of being in the room are due you need to sign out', '30/11/2016  23:59:06', 0),
	(48, 2, NULL, NULL, 'You need to signed Out', 'Your days of being in the room are due you need to sign out', '30/11/2016  23:59:24', 0),
	(49, 2, NULL, NULL, 'You need to signed Out', 'Your days of being in the room are due you need to sign out', '01/12/2016  00:17:59', 0),
	(50, 2, NULL, NULL, 'You need to signed Out', 'Your days of being in the room are due you need to sign out', '01/12/2016  00:18:48', 0),
	(51, 2, NULL, NULL, 'You need to signed Out', 'Your days of being in the room are due you need to sign out', '01/12/2016  00:19:27', 0);
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;


-- Dumping structure for table norem.payments
DROP TABLE IF EXISTS `payments`;
CREATE TABLE IF NOT EXISTS `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenantID` int(11) NOT NULL DEFAULT '0',
  `landLordID` int(11) NOT NULL DEFAULT '0',
  `Amount` int(11) NOT NULL DEFAULT '0',
  `Balance` int(11) NOT NULL DEFAULT '0',
  `Month` varchar(50) NOT NULL DEFAULT '0',
  `Year` int(11) NOT NULL DEFAULT '0',
  `Date` varchar(50) NOT NULL DEFAULT '0',
  `Room` varchar(50) NOT NULL DEFAULT '0',
  `Plot` varchar(50) NOT NULL DEFAULT '0',
  `Purpose` varchar(50) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- Dumping data for table norem.payments: ~5 rows (approximately)
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
REPLACE INTO `payments` (`id`, `tenantID`, `landLordID`, `Amount`, `Balance`, `Month`, `Year`, `Date`, `Room`, `Plot`, `Purpose`) VALUES
	(2, 3, 3, 3500, 0, 'SEPT', 2016, '21/11/2016  12:48:43', 'R0022', 'kiambion', 'RENT'),
	(3, 2, 3, 2000, 0, 'FEB', 2016, '22/11/2016  11:11:23', 'R001', 'Koitabut', 'RENT'),
	(4, 4, 3, 2000, 0, 'JUN', 2016, '30/11/2016  23:52:06', 'R004t5', 'Ruaie', 'DAMAGES'),
	(5, 1, 3, 2000, 0, 'NOV', 2016, '29/11/2016  18:26:42', 'R001', 'Koitabuit', 'RENT'),
	(6, 1, 3, 500, 0, 'DEC', 2016, '29/11/2016  18:27:11', 'R001', 'Koitabuit', 'DAMAGES');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;


-- Dumping structure for table norem.plots
DROP TABLE IF EXISTS `plots`;
CREATE TABLE IF NOT EXISTS `plots` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `landlord_id` int(11) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `location` varchar(50) NOT NULL,
  `photo` mediumblob,
  PRIMARY KEY (`id`),
  KEY `FK_plots_landlord` (`landlord_id`),
  CONSTRAINT `FK_plots_landlord` FOREIGN KEY (`landlord_id`) REFERENCES `landlord` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;




-- Dumping structure for table norem.request
DROP TABLE IF EXISTS `request`;
CREATE TABLE IF NOT EXISTS `request` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `plot_id` int(11) NOT NULL DEFAULT '0',
  `room_id` int(11) NOT NULL DEFAULT '0',
  `dat` varchar(50) NOT NULL DEFAULT '0000-00-00',
  `duration` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  `prefRoommate` varchar(50) DEFAULT NULL,
  `dueDate` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_request_plots` (`plot_id`),
  KEY `FK_request_room` (`room_id`),
  KEY `FK_request_users` (`user_id`),
  CONSTRAINT `FK_request_plots` FOREIGN KEY (`plot_id`) REFERENCES `plots` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_request_room` FOREIGN KEY (`room_id`) REFERENCES `room` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_request_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table norem.request: ~0 rows (approximately)
/*!40000 ALTER TABLE `request` DISABLE KEYS */;
/*!40000 ALTER TABLE `request` ENABLE KEYS */;


-- Dumping structure for view norem.requestdata
DROP VIEW IF EXISTS `requestdata`;
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `requestdata` (
	`requestid` INT(11) NOT NULL,
	`duration` INT(11) NOT NULL,
	`dat` VARCHAR(50) NOT NULL COLLATE 'latin1_swedish_ci',
	`prefRoommate` VARCHAR(50) NULL COLLATE 'latin1_swedish_ci',
	`stat` INT(11) NOT NULL,
	`landlord_id` INT(11) NULL,
	`plotName` VARCHAR(50) NOT NULL COLLATE 'latin1_swedish_ci',
	`roomName` VARCHAR(50) NOT NULL COLLATE 'latin1_swedish_ci',
	`userName` VARCHAR(103) NOT NULL COLLATE 'latin1_swedish_ci',
	`photo` MEDIUMBLOB NOT NULL,
	`gender` VARCHAR(50) NOT NULL COLLATE 'latin1_swedish_ci',
	`phone` VARCHAR(50) NOT NULL COLLATE 'latin1_swedish_ci'
) ENGINE=MyISAM;


-- Dumping structure for table norem.room
DROP TABLE IF EXISTS `room`;
CREATE TABLE IF NOT EXISTS `room` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `rent` int(11) NOT NULL,
  `plotId` int(11) NOT NULL,
  `details` varchar(50) NOT NULL DEFAULT 'no details given',
  `con` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `capacity` int(11) NOT NULL,
  `occupants` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_room_plots` (`plotId`),
  CONSTRAINT `FK_room_plots` FOREIGN KEY (`plotId`) REFERENCES `plots` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

-- Dumping data for table norem.room: ~4 rows (approximately)
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
REPLACE INTO `room` (`id`, `name`, `rent`, `plotId`, `details`, `con`, `status`, `capacity`, `occupants`) VALUES
	(6, 'R003', 2000, 7, 'three bedroom house with no water', 'Good', 1, 10, 1),
	(8, 'R003', 2000, 10, 'good floor', 'Avarage', 1, 4, 1),
	(9, 'ROOM1', 3000, 12, 'nice floor', 'Good', 1, 4, 0),
	(10, 'R004t5', 2000, 10, 'good floor', 'Avarage', 1, 4, 2);
/*!40000 ALTER TABLE `room` ENABLE KEYS */;


-- Dumping structure for table norem.roomallocation
DROP TABLE IF EXISTS `roomallocation`;
CREATE TABLE IF NOT EXISTS `roomallocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plot_id` int(11) NOT NULL DEFAULT '0',
  `room_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `pRoommate` varchar(50) DEFAULT '0',
  `Status` int(11) DEFAULT '1',
  `evacuatedate` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_roomAllocation_plots` (`plot_id`),
  KEY `FK_roomAllocation_room` (`room_id`),
  KEY `FK_roomAllocation_users` (`user_id`),
  CONSTRAINT `FK_roomAllocation_plots` FOREIGN KEY (`plot_id`) REFERENCES `plots` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_roomAllocation_room` FOREIGN KEY (`room_id`) REFERENCES `room` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_roomAllocation_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

-- Dumping data for table norem.roomallocation: ~2 rows (approximately)
/*!40000 ALTER TABLE `roomallocation` DISABLE KEYS */;
REPLACE INTO `roomallocation` (`id`, `plot_id`, `room_id`, `date`, `user_id`, `pRoommate`, `Status`, `evacuatedate`) VALUES
	(15, 7, 6, '2016-11-15 14:51:01', 1, 'Cheruyiot', 1, '29/01/2017'),
	(16, 7, 6, '2016-11-22 11:10:31', 2, 'Kibet', 1, '29/01/2016'),
	(17, 10, 10, '2016-11-30 22:38:51', 4, 'null', 1, '29/01/2017');
/*!40000 ALTER TABLE `roomallocation` ENABLE KEYS */;


-- Dumping structure for view norem.roomallocationview
DROP VIEW IF EXISTS `roomallocationview`;
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `roomallocationview` (
	`roomallocationId` INT(11) NOT NULL,
	`pRoommate` VARCHAR(50) NULL COLLATE 'latin1_swedish_ci',
	`plotname` VARCHAR(50) NOT NULL COLLATE 'latin1_swedish_ci',
	`landlord_id` INT(11) NULL,
	`roomname` VARCHAR(50) NOT NULL COLLATE 'latin1_swedish_ci',
	`username` VARCHAR(101) NOT NULL COLLATE 'latin1_swedish_ci'
) ENGINE=MyISAM;


-- Dumping structure for view norem.tenants
DROP VIEW IF EXISTS `tenants`;
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `tenants` (
	`id` INT(11) NOT NULL,
	`date` DATETIME NOT NULL,
	`PlotName` VARCHAR(50) NOT NULL COLLATE 'latin1_swedish_ci',
	`landlord_id` INT(11) NULL,
	`plotId` INT(11) NOT NULL,
	`RoomId` INT(11) NOT NULL,
	`roomName` VARCHAR(50) NOT NULL COLLATE 'latin1_swedish_ci',
	`rent` INT(11) NOT NULL,
	`Conditin` VARCHAR(50) NOT NULL COLLATE 'latin1_swedish_ci',
	`status` INT(11) NOT NULL,
	`capacity` INT(11) NOT NULL,
	`occupants` INT(11) NOT NULL,
	`photo` MEDIUMBLOB NOT NULL,
	`username` VARCHAR(103) NOT NULL COLLATE 'latin1_swedish_ci',
	`phone` VARCHAR(50) NOT NULL COLLATE 'latin1_swedish_ci',
	`gender` VARCHAR(50) NOT NULL COLLATE 'latin1_swedish_ci',
	`nationalId` INT(11) NOT NULL,
	`userId` INT(11) NOT NULL
) ENGINE=MyISAM;


-- Dumping structure for table norem.users
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(50) NOT NULL,
  `sname` varchar(50) NOT NULL,
  `nationalId` int(11) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `photo` mediumblob NOT NULL,
  `email` varchar(50) NOT NULL,
  `scannedId` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;




-- Dumping structure for view norem.requestdata
DROP VIEW IF EXISTS `requestdata`;
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `requestdata`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` VIEW `requestdata` AS SELECT T1.id AS requestid,T1.duration as duration,T1.dat,T1.prefRoommate,T1.`status` as stat,T3.landlord_id, T3.name AS plotName,T2.name AS roomName,CONCAT(T4.fname,'   ',T4.sname) AS userName,T4.photo AS photo,T4.gender as gender,T4.phone as phone FROM request AS T1 INNER JOIN room AS T2 ON T1.room_id=T2.id INNER JOIN plots AS T3 ON T1.plot_id=T3.id INNER JOIN users AS T4 On T1.user_id=T4.id ;


-- Dumping structure for view norem.roomallocationview
DROP VIEW IF EXISTS `roomallocationview`;
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `roomallocationview`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` VIEW `roomallocationview` AS SELECT T1.id as roomallocationId,T1.pRoommate,T2.name as plotname,T2.landlord_id,T3.name as roomname,concat(T4.fname,' ',T4.sname ) as username FROM roomallocation AS T1 INNER JOIN plots AS T2 ON T1.plot_id=T2.id INNER JOIN room as T3 ON T1.room_id = T3.id INNER JOin users AS T4 on T1.user_id=T4.id ;


-- Dumping structure for view norem.tenants
DROP VIEW IF EXISTS `tenants`;
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `tenants`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` VIEW `tenants` AS SELECT T1.id,T1.date, T2.name as PlotName ,T2.landlord_id,T2.id AS plotId,T3.id AS RoomId, T3.name AS roomName,T3.rent,T3.con AS Conditin,T3.`status`,T3.capacity,T3.occupants,T4.photo,concat(T4.fname,'   ',T4.sname) AS username,T4.phone,T4.gender,T4.nationalId,T4.id As userId FROM roomallocation AS T1 inner join  plots AS T2 on T1.plot_id=T2.id INNER JOIN room AS T3 on T1.room_id=T3.id INNER JOIN users AS T4 on T1.user_id=T4.id Where T1.`Status`=1 ;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
